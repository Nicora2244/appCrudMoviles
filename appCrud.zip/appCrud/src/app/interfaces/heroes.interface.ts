export interface Heroe{
    _id: string;
    nombre: string;
    bio: string;
    img: string;
    aparicion: string;
    casa: string;
  };


//Generado por la IA, pasandole el JSON  
export  interface Personaje {
    _id: string;
    nombre: string;
    bio: string;
    img: string;
    aparicion: string; // ISO date string
    casa: string;
  }